# PHP-Pure-investment-website

A fully PHP PURE written website for a customer. One of my earliest projects. It is written with passion and is fully pure without the use of any frameworks 

It was built for crypto investments and statistics.

! enjoy.
