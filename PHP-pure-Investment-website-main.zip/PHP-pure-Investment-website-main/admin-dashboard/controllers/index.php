<?php
// Silence is key